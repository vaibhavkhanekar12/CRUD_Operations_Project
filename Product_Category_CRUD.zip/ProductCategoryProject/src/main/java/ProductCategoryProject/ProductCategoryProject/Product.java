package ProductCategoryProject.ProductCategoryProject;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	private int productid;
	private String product;
	private int price;

	public Product() {
		super();
	}

	public Product(int productid, String product, int price) {
		super();
		this.productid = productid;
		this.product = product;
		this.price = price;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [productid=" + productid + ", product=" + product + ", price=" + price + "]";
	}

}
