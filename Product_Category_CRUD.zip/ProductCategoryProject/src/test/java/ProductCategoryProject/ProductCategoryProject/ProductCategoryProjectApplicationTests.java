package ProductCategoryProject.ProductCategoryProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCategoryProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
